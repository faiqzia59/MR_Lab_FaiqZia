from setuptools import setup

package_name = 'recovery_system'

setup(
    name=package_name,
    version='0.0.1',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Faiq',
    maintainer_email='faiq@todo.todo',
    description='Intelligent Recovery Behavior System',
    license='MIT',
    entry_points={
        'console_scripts': [
            'intelligent_recovery = recovery_system.intelligent_recovery:main',
        ],
    },
)
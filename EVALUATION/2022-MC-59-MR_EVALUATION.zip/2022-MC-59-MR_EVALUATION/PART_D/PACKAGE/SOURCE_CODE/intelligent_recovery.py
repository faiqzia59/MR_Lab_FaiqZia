#!/usr/bin/env python3

import time
import math
import threading

import rclpy
from rclpy.node import Node

from geometry_msgs.msg import Twist
from nav2_msgs.msg import ParticleCloud

from std_srvs.srv import Empty

from rclpy.qos import QoSProfile
from rclpy.qos import ReliabilityPolicy
from rclpy.qos import HistoryPolicy


class RecoveryNode(Node):

    def __init__(self):

        super().__init__('recovery_node')

        print("\n========== RECOVERY NODE STARTED ==========\n")

        # CHANGE IF NEEDED
        self.cmd_topic = '/cmd_vel_nav'

        # LOCALIZATION QUALITY THRESHOLD
        self.spread_threshold = 0.5

        self.current_spread = 0.0

        self.recovering = False

        # CMD VEL PUBLISHER
        self.cmd_pub = self.create_publisher(
            Twist,
            self.cmd_topic,
            10
        )

        print(f"Publishing to {self.cmd_topic}")

        # QoS FIX FOR AMCL PARTICLE CLOUD
        qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=10
        )

        # PARTICLE CLOUD SUBSCRIBER
        self.particle_sub = self.create_subscription(
            ParticleCloud,
            '/particle_cloud',
            self.particle_callback,
            qos
        )

        print("Subscribed to /particle_cloud")

    def particle_callback(self, msg):

        print("\n========== PARTICLE CALLBACK ==========\n")

        particles = msg.particles

        print(f"Particle count: {len(particles)}")

        if len(particles) < 5:

            print("Too few particles")

            return

        spread = self.compute_spread(particles)

        self.current_spread = spread

        print(f"Particle spread = {spread:.3f}")

        # BAD LOCALIZATION
        if spread > self.spread_threshold:

            print("LOCALIZATION BAD")

            if not self.recovering:

                print("STARTING RECOVERY")

                self.recovering = True

                threading.Thread(
                    target=self.run_recovery,
                    daemon=True
                ).start()

        else:

            print("LOCALIZATION GOOD")

    def compute_spread(self, particles):

        xs = []
        ys = []

        for p in particles:

            xs.append(p.pose.position.x)
            ys.append(p.pose.position.y)

        mean_x = sum(xs) / len(xs)
        mean_y = sum(ys) / len(ys)

        variance = 0.0

        for x, y in zip(xs, ys):

            variance += (
                (x - mean_x) ** 2 +
                (y - mean_y) ** 2
            )

        variance /= len(xs)

        return math.sqrt(variance)

    def run_recovery(self):

        print(
            "\n========== RUNNING RECOVERY ==========\n"
        )

        # REINITIALIZE AMCL
        self.call_service(
            '/reinitialize_global_localization'
        )

        # ROTATE ROBOT
        twist = Twist()

        twist.linear.x = 0.0
        twist.angular.z = 0.8

        while self.current_spread > self.spread_threshold:

            self.cmd_pub.publish(twist)

            print(
                f"ROTATING | spread={self.current_spread:.3f}"
            )

            time.sleep(0.1)

        # STOP ROBOT
        stop = Twist()

        self.cmd_pub.publish(stop)

        print(
            "\n========== RECOVERY COMPLETE ==========\n"
        )

        self.recovering = False

    def call_service(self, service_name):

        print(f"\nCalling service: {service_name}")

        client = self.create_client(
            Empty,
            service_name
        )

        if not client.wait_for_service(
            timeout_sec=3.0
        ):

            print(
                f"SERVICE NOT FOUND: {service_name}"
            )

            return

        request = Empty.Request()

        client.call_async(request)

        print(f"Service called: {service_name}")


def main(args=None):

    print("Initializing ROS2")

    rclpy.init(args=args)

    node = RecoveryNode()

    print("ROS2 spinning...")

    rclpy.spin(node)

    node.destroy_node()

    rclpy.shutdown()


if __name__ == '__main__':

    main()